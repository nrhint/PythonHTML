print("STARTING...")
##Do stuff
print("This will create a HTML file for you where you will type inf the text and then be able yo use it in a webpage.")
print()
print()
fileName = input("What will the name of your file be? (use index of its the first file in the web pages).  ")
openFile = open(str(fileName) + ".html", 'x')
openFile.write("This file was created by a programm for making HTML files.")
##opening HTML tag
openFile.write("<html>")
##opening head tag
openFile.write(" <head>")
titleBar = input("What will the title bar display?  ")
openFile.write(titleBar)
##closing head tag
openFile.write(" </head>")
##opening body tag
openFile.write(" <body>")
openFile.write("  <H1>")
##insert the page title
pageTitle = input("What will be the page title?  ")
openFile.write("   TEST " + pageTitle)
openFile.write("  </H1>")
openFile.write("  <p>")
##insert main body content
mainBody = input("insert the main body text:  ")
openFile.write("   TEST " + mainBody)
openFile.write("  </p>")
##closing body tag
openFile.write(" </body>")
##closing HTML tag
openFile.write("</html>")
openFile.close()

